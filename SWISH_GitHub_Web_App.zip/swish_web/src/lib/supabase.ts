import { createClient, SupabaseClient } from '@supabase/supabase-js';

// SWISH/GitHub Pages frontend uses the existing OnSpace backend.
// The anon key is a public Supabase client key; eBay secrets/tokens remain server-side.
export const BACKEND_URL = 'https://iwgaqieyoahmcjfziwga.backend.onspace.ai';
export const ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3ODkwNjM4MTgsImV4cCI6MjEwNDQyMzgxOCwicmVmIjoiaXdnYXFpZXlvYWhtY2pmeml3Z2EiLCJyb2xlIjoiYW5vbiIsImlzcyI6Im9uc3BhY2UifQ.cioQ38guPLFAbl3x48mUaJcMSxU5IpZn7-H-JhtvXJc';
const TENANT_CACHE = 'swish_tenant_id';

let _client: SupabaseClient | null = null;
export function getStoredAnonKey(): string { return ANON_KEY; }
export function storeAnonKey(_key: string): void { /* fixed canonical public anon key */ }
export function clearStoredAnonKey(): void { /* never remove canonical config */ }

export function getSupabaseClient(): SupabaseClient {
  if (!_client) {
    _client = createClient(BACKEND_URL, ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: 'swish_auth' },
      global: { headers: { 'x-client-info': 'swish-github-web' } },
    });
  }
  return _client;
}
export function initSupabase(_anonKey?: string): SupabaseClient { return getSupabaseClient(); }
export function resetClient(): void { _client = null; }

export async function getTenantId(client = getSupabaseClient()): Promise<string> {
  const cached = localStorage.getItem(TENANT_CACHE);
  if (cached) return cached;
  const { data, error } = await client.from('tenants').select('id').order('created_at', { ascending: true }).limit(1);
  if (error) throw error;
  const id = (data?.[0] as { id?: string } | undefined)?.id;
  if (!id) throw new Error('No SWISH tenant found. Sign in to the existing SWISH account.');
  localStorage.setItem(TENANT_CACHE, id);
  return id;
}

export const FN = {
  browse: 'swish-ebay-browse',
  list: 'swish-ebay-list',
  taxonomy: 'swish-ebay-taxonomy',
  messages: 'swish-ebay-messages',
  orders: 'swish-ebay-orders',
  postOrder: 'swish-ebay-post-order',
  sync: 'swish-ebay-sync',
  identify: 'swish-identify',
  islamic: 'swish-islamic-identify',
  image: 'swish-image-download',
  reprice: 'swish-reprice',
  decompose: 'swish-decompose',
  marketValue: 'swish-market-value',
  generate: 'swish-list-generate',
};

function itemKnownAttributes(item: Record<string, unknown>) {
  const attrs = (item.attributes && typeof item.attributes === 'object') ? item.attributes as Record<string, unknown> : {};
  return { ...attrs, weight: item.weight, diameter: item.diameter, condition: item.condition, sku: item.sku };
}

async function loadItem(id: string) {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('items').select('*').eq('id', id).single();
  if (error) throw error;
  return data as Record<string, unknown>;
}

export async function callEdgeFunction(fn: string, payload: Record<string, unknown> = {}, client = getSupabaseClient()): Promise<{ data: any; error: Error | null }> {
  try {
    const tenantId = payload.tenantId || await getTenantId(client);
    let actual = fn;
    let body: Record<string, unknown> = { ...payload, tenantId };

    // Compatibility aliases used by the old OnSpace-generated UI -> production SWISH functions.
    if (fn === 'identify') {
      actual = FN.identify;
      if (payload.item_id && !payload.existingImageUrls) {
        const item = await loadItem(String(payload.item_id));
        body = { tenantId, existingImageUrls: Array.isArray(item.media) ? item.media : [], specialistId: item.specialist_id || 'curiosities_collectibles', knownAttributes: itemKnownAttributes(item) };
      } else {
        body = { ...body, existingImageUrls: payload.existingImageUrls || payload.images || [], specialistId: payload.specialistId || 'curiosities_collectibles' };
      }
    } else if (fn === 'value') {
      actual = FN.marketValue;
      const item = payload.item_id ? await loadItem(String(payload.item_id)) : null;
      if (item) {
        const attrs = (item.attributes && typeof item.attributes === 'object') ? item.attributes as Record<string, unknown> : {};
        body = { tenantId, itemId: item.id, title: item.canonical_title || 'Unknown item', specialistId: item.specialist_id || 'curiosities_collectibles', attributes: attrs, condition: item.condition || '', identificationConfidence: Number(item.identification_confidence ?? 0), identificationTier: Number(item.identification_confidence ?? 0) >= .85 ? 'high' : Number(item.identification_confidence ?? 0) >= .65 ? 'medium' : 'low', numistaTypeId: attrs.numista_type_id ? Number(attrs.numista_type_id) : null, numistaMatchScore: Number(attrs.numista_match_score || 0), numistaMatchTier: attrs.numista_status || 'no_match', applyToItem: true };
      }
    } else if (fn === 'ebay-sync' || fn === 'ebay-sync-listings') {
      actual = FN.sync; body = { tenantId, mode: 'full' };
    } else if (fn === 'ebay-reply-message') {
      actual = FN.messages;
      body = { tenantId, route: 'send_reply', messageId: payload.message_id, replyText: payload.body, buyerUsername: payload.buyer_username, ebayItemId: payload.ebay_item_id, conversationId: payload.conversation_id };
    } else if (fn === 'ebay-analytics') {
      // Analytics are derived from the canonical orders/financial tables; no fake Edge Function is invented.
      const { data, error } = await client.from('orders').select('*').eq('platform', 'ebay').order('created_at', { ascending: false }).limit(1000);
      if (error) throw error;
      const orders = data || [];
      const revenue = orders.reduce((n: number, o: any) => n + Number(o.total_amount || o.sale_price || 0), 0);
      return { data: { orderCount: orders.length, revenue, source: 'canonical orders table' }, error: null };
    } else if (fn === 'ebay-finances' || fn === 'ebay-finances-summary') {
      const { data, error } = await client.from('ebay_financials').select('*').order('created_at', { ascending: false }).limit(500);
      if (error) throw error;
      return { data: { transactions: data || [], count: data?.length || 0 }, error: null };
    } else if (fn === 'listing-preflight') {
      actual = FN.taxonomy; body = { tenantId, route: 'verify_leaf', categoryId: payload.categoryId || payload.category_id };
    } else if (fn === 'publish-listing') {
      actual = FN.list; body = { tenantId, listingId: payload.listingId || payload.listing_id, listingType: payload.listingType || 'FIXED_PRICE', categoryId: payload.categoryId || payload.category_id, title: payload.title, description: payload.description, price: Number(payload.price || 0), quantity: Number(payload.quantity || 1), condition: payload.condition, conditionDescription: payload.conditionDescription, itemSpecifics: payload.itemSpecifics || [], mediaUrls: payload.mediaUrls || [], deliveryMethod: 'SIMPLE_DELIVERY' };
    } else if (fn === 'end-listing') {
      actual = FN.list; body = { tenantId, route: 'end', listingId: payload.listingId || payload.listing_id, externalListingId: payload.externalListingId || payload.external_id };
    } else if (fn === 'reprice') {
      actual = FN.reprice; body = { tenantId, listingId: payload.listing_id, itemId: payload.item_id };
    } else if (fn === 'reprice-all') {
      actual = FN.reprice; body = { tenantId, mode: 'all' };
    } else if (fn === 'ebay-return-action' || fn === 'ebay-case-respond' || fn === 'ebay-offer-action') {
      throw new Error(`This action is not exposed by the existing SWISH backend as a safe client route. Use Sync/Refresh to pull the current eBay state.`);
    }

    const { data, error } = await client.functions.invoke(actual, { body });
    return { data, error: error ? new Error(error.message) : null };
  } catch (e) {
    return { data: null, error: e instanceof Error ? e : new Error(String(e)) };
  }
}

export function getStorageUrl(path: string): string { return `${BACKEND_URL}/storage/v1/object/public/${path}`; }
