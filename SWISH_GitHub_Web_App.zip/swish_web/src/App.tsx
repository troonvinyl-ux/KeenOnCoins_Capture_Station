import { Toaster } from '@/components/ui/toaster';
import { Toaster as Sonner } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/layout/AppLayout';

import LoginPage from '@/pages/LoginPage';
import Dashboard from '@/pages/Dashboard';
import Inventory from '@/pages/Inventory';
import InventoryItem from '@/pages/InventoryItem';
import Identify from '@/pages/Identify';
import Acquisitions from '@/pages/Acquisitions';
import Opportunities from '@/pages/Opportunities';
import ReviewRequired from '@/pages/ReviewRequired';
import Audit from '@/pages/Audit';
import Listings from '@/pages/Listings';
import ListingEditor from '@/pages/ListingEditor';
import Orders from '@/pages/Orders';
import Dispatch from '@/pages/Dispatch';
import Repricing from '@/pages/Repricing';
import Insights from '@/pages/Insights';
import Money from '@/pages/Money';
import Tasks from '@/pages/Tasks';
import CommandCentre from '@/pages/CommandCentre';
import EbayHub from '@/pages/EbayHub';
import EbayListings from '@/pages/EbayListings';
import EbayOrders from '@/pages/EbayOrders';
import EbayMessages from '@/pages/EbayMessages';
import EbayOffers from '@/pages/EbayOffers';
import EbayReturns from '@/pages/EbayReturns';
import EbayCases from '@/pages/EbayCases';
import EbayFinances from '@/pages/EbayFinances';
import EbayAnalytics from '@/pages/EbayAnalytics';
import EbayImport from '@/pages/EbayImport';
import EbayLogs from '@/pages/EbayLogs';
import Settings from '@/pages/Settings';
import NotFound from '@/pages/NotFound';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30000 },
  },
});

function AppRoutes() {
  const { loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) return <LoginPage />;

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/command-centre" element={<CommandCentre />} />

        {/* Inventory */}
        <Route path="/inventory" element={<Inventory />} />
        <Route path="/inventory/new" element={<Identify />} />
        <Route path="/inventory/:id" element={<InventoryItem />} />
        <Route path="/identify" element={<Identify />} />
        <Route path="/acquisitions" element={<Acquisitions />} />
        <Route path="/opportunities" element={<Opportunities />} />
        <Route path="/review-required" element={<ReviewRequired />} />
        <Route path="/audit" element={<Audit />} />

        {/* Selling */}
        <Route path="/listings" element={<Listings />} />
        <Route path="/listings/:id" element={<ListingEditor />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/dispatch" element={<Dispatch />} />
        <Route path="/repricing" element={<Repricing />} />

        {/* Analytics */}
        <Route path="/insights" element={<Insights />} />
        <Route path="/money" element={<Money />} />

        {/* Tasks */}
        <Route path="/tasks" element={<Tasks />} />

        {/* eBay */}
        <Route path="/ebay" element={<EbayHub />} />
        <Route path="/ebay/listings" element={<EbayListings />} />
        <Route path="/ebay/orders" element={<EbayOrders />} />
        <Route path="/ebay/messages" element={<EbayMessages />} />
        <Route path="/ebay/offers" element={<EbayOffers />} />
        <Route path="/ebay/returns" element={<EbayReturns />} />
        <Route path="/ebay/cases" element={<EbayCases />} />
        <Route path="/ebay/finances" element={<EbayFinances />} />
        <Route path="/ebay/analytics" element={<EbayAnalytics />} />
        <Route path="/ebay/import" element={<EbayImport />} />
        <Route path="/ebay/logs" element={<EbayLogs />} />

        {/* Settings */}
        <Route path="/settings" element={<Settings />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </AppLayout>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="bottom-right" />
      <HashRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </HashRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
