import { useTable } from '@/hooks/useSupabaseQuery';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Wallet, RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { callEdgeFunction } from '@/lib/supabase';
import { useState, useEffect } from 'react';

export default function Money() {
  const qc = useQueryClient();
  const { data: ordersData } = useTable('orders', { order: { column: 'created_at', ascending: false }, limit: 200 });
  const { data: feesData } = useTable('fees', { order: { column: 'created_at', ascending: false }, limit: 100 });
  const { data: payoutsData } = useTable('payouts', { order: { column: 'created_at', ascending: false }, limit: 50 });

  const [ebayBalance, setEbayBalance] = useState<Record<string, unknown> | null>(null);

  useEffect(() => {
    callEdgeFunction('ebay-finances-summary', {}).then(({ data }) => {
      if (data) setEbayBalance(data as Record<string, unknown>);
    });
  }, []);

  const orders = (ordersData || []) as Record<string, unknown>[];
  const fees = (feesData || []) as Record<string, unknown>[];
  const payouts = (payoutsData || []) as Record<string, unknown>[];

  const totalRevenue = orders.reduce((s, o) => s + Number((o.total_amount || o.sale_price) || 0), 0);
  const totalFees = fees.reduce((s, f) => s + Number(f.amount || 0), 0);
  const totalPayouts = payouts.reduce((s, p) => s + Number(p.amount || 0), 0);
  const netRevenue = totalRevenue - totalFees;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Money</h1>
          <p className="page-subtitle">Financial overview from your real data</p>
        </div>
        <button onClick={() => { qc.invalidateQueries({ queryKey: ['orders'] }); qc.invalidateQueries({ queryKey: ['fees'] }); qc.invalidateQueries({ queryKey: ['payouts'] }); }} className="btn-ghost">
          <RefreshCw className="w-3.5 h-3.5" />Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Gross Revenue', value: formatCurrency(totalRevenue), icon: TrendingUp, positive: true },
          { label: 'Total Fees', value: formatCurrency(totalFees), icon: TrendingDown, positive: false },
          { label: 'Net Revenue', value: formatCurrency(netRevenue), icon: Wallet, positive: netRevenue >= 0 },
          { label: 'Total Payouts', value: formatCurrency(totalPayouts), icon: Wallet, positive: true },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="flex justify-between items-start">
              <div>
                <div className={`text-2xl font-bold ${s.positive ? 'swish-gold' : 'text-destructive'}`}>{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
              <s.icon className={`w-5 h-5 ${s.positive ? 'swish-gold' : 'text-destructive'}`} />
            </div>
          </div>
        ))}
      </div>

      {ebayBalance && (
        <div className="swish-card p-4">
          <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <span className="text-xs font-bold bg-primary text-primary-foreground px-1.5 py-0.5 rounded">eB</span>
            eBay Financial Summary
          </h3>
          <pre className="text-xs text-muted-foreground bg-secondary/40 p-3 rounded overflow-auto max-h-48 scrollbar-thin">
            {JSON.stringify(ebayBalance, null, 2)}
          </pre>
        </div>
      )}

      {/* Payouts */}
      {payouts.length > 0 && (
        <div className="swish-card p-4">
          <h3 className="text-sm font-semibold mb-3">Recent Payouts</h3>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr><th>Date</th><th>Platform</th><th>Status</th><th className="text-right">Amount</th></tr></thead>
              <tbody>
                {payouts.slice(0, 20).map(p => (
                  <tr key={p.id as string}>
                    <td className="text-xs">{formatDate(p.created_at as string)}</td>
                    <td className="text-xs capitalize">{(p.platform || '—') as string}</td>
                    <td className="text-xs">{(p.status || '—') as string}</td>
                    <td className="text-right text-xs font-semibold swish-gold">{formatCurrency(p.amount as number)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
