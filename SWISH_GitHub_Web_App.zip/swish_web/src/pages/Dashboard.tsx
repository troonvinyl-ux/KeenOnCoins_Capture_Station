import { useAuth } from '@/contexts/AuthContext';
import { useTable, useCount } from '@/hooks/useSupabaseQuery';
import { formatCurrency, formatRelative, statusVariant } from '@/lib/utils';
import { Package, Tag, ShoppingCart, Truck, CheckSquare, AlertCircle, TrendingUp, Wallet } from 'lucide-react';
import { Link } from 'react-router-dom';

function StatCard({ label, value, icon: Icon, to, color = 'swish-gold' }: {
  label: string; value: string | number; icon: React.ComponentType<{ className?: string }>;
  to: string; color?: string;
}) {
  return (
    <Link to={to} className="stat-card hover:border-primary/40 transition-colors block">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-2xl font-bold">{value}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
        </div>
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-4 h-4 swish-gold" />
        </div>
      </div>
    </Link>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { data: inventory } = useTable('inventory', { limit: 5, order: { column: 'created_at', ascending: false } });
  const { data: orders } = useTable('orders', { limit: 5, order: { column: 'created_at', ascending: false } });
  const { data: tasks } = useTable('tasks', { limit: 5, filter: { status: 'open' } });

  const { data: invCount } = useCount('inventory');
  const { data: listingCount } = useCount('listings', { status: 'active' });
  const { data: orderCount } = useCount('orders');
  const { data: dispatchCount } = useCount('orders', { status: 'awaiting_dispatch' });
  const { data: taskCount } = useCount('tasks', { status: 'open' });

  const items: { label: string; value: string | number; icon: React.ComponentType<{ className?: string }>; to: string }[] = [
    { label: 'Total Inventory', value: invCount ?? '—', icon: Package, to: '/inventory' },
    { label: 'Active Listings', value: listingCount ?? '—', icon: Tag, to: '/listings' },
    { label: 'Total Orders', value: orderCount ?? '—', icon: ShoppingCart, to: '/orders' },
    { label: 'Pending Dispatch', value: dispatchCount ?? '—', icon: Truck, to: '/dispatch' },
    { label: 'Open Tasks', value: taskCount ?? '—', icon: CheckSquare, to: '/tasks' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome */}
      <div>
        <h1 className="text-xl font-bold">Welcome back{user?.email ? `, ${user.email.split('@')[0]}` : ''}</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Here's what's happening with your SWISH account</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {items.map(s => <StatCard key={s.to} {...s} />)}
      </div>

      {/* Recent activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {/* Recent inventory */}
        <div className="swish-card p-4 lg:col-span-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Recent Inventory</h3>
            <Link to="/inventory" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {inventory?.length ? (
            <div className="space-y-2">
              {inventory.map((item: Record<string, unknown>) => (
                <Link key={item.id as string} to={`/inventory/${item.id}`} className="flex items-center gap-3 p-2 rounded-md hover:bg-secondary/40 transition-colors">
                  <div className="w-8 h-8 rounded bg-secondary flex items-center justify-center shrink-0">
                    {item.image_url ? (
                      <img src={item.image_url as string} alt="" className="w-8 h-8 rounded object-cover" />
                    ) : (
                      <Package className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">{(item.title || item.name || item.sku || 'Untitled') as string}</div>
                    <div className="text-xs text-muted-foreground">{formatRelative(item.created_at as string)}</div>
                  </div>
                  {item.status && <span className={statusVariant(item.status as string)}>{item.status as string}</span>}
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-4">No inventory yet</p>
          )}
        </div>

        {/* Recent orders */}
        <div className="swish-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Recent Orders</h3>
            <Link to="/orders" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {orders?.length ? (
            <div className="space-y-2">
              {orders.map((order: Record<string, unknown>) => (
                <div key={order.id as string} className="flex items-center gap-3 p-2 rounded-md hover:bg-secondary/40 transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">
                      {(order.item_title || order.external_order_id || order.order_id || 'Order') as string}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {(order.buyer_name || order.buyer_username || '') as string} · {formatRelative(order.created_at as string)}
                    </div>
                  </div>
                  <div className="text-xs font-semibold swish-gold">
                    {formatCurrency((order.total_amount || order.sale_price) as number)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-4">No recent orders</p>
          )}
        </div>

        {/* Open tasks */}
        <div className="swish-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Open Tasks</h3>
            <Link to="/tasks" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {tasks?.length ? (
            <div className="space-y-2">
              {tasks.map((task: Record<string, unknown>) => (
                <div key={task.id as string} className="flex items-center gap-2 p-2 rounded-md hover:bg-secondary/40">
                  <CheckSquare className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs truncate">{(task.title || 'Untitled task') as string}</div>
                  </div>
                  {task.priority && <span className="text-xs text-muted-foreground">{task.priority as string}</span>}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-4">No open tasks</p>
          )}
        </div>
      </div>
    </div>
  );
}
