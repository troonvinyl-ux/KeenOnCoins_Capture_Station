import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Eye, EyeOff, Zap, Key } from 'lucide-react';
import { toast } from 'sonner';

export default function SetupScreen() {
  const { setAnonKey } = useAuth();
  const [key, setKey] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  const handle = () => {
    if (!key.trim()) { toast.error('Enter your API key'); return; }
    setLoading(true);
    setAnonKey(key.trim());
    setTimeout(() => setLoading(false), 800);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-3xl font-bold swish-gold" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>SWISH</span>
          </div>
          <p className="text-muted-foreground text-sm">Web Edition</p>
        </div>

        <div className="swish-card p-6 space-y-5">
          <div>
            <h2 className="text-base font-semibold mb-1">Connect to Backend</h2>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Enter your project's anon/public key to connect to{' '}
              <code className="bg-secondary px-1 py-0.5 rounded text-primary text-[11px]">
                iwgaqieyoahmcjfziwga.backend.onspace.ai
              </code>
              . Find it in OnSpace Cloud → Settings.
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1.5 text-muted-foreground">
              <Key className="w-3 h-3 inline mr-1" />Anon / Public Key
            </label>
            <div className="relative">
              <input
                type={show ? 'text' : 'password'}
                value={key}
                onChange={e => setKey(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handle()}
                placeholder="eyJhbGciOiJIUzI1NiIs..."
                className="input-field pr-10 font-mono text-xs"
                autoComplete="off"
              />
              <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button onClick={handle} disabled={loading || !key.trim()} className="btn-primary w-full justify-center py-2.5">
            {loading ? 'Connecting…' : 'Connect'}
          </button>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-5">
          Key stored in session memory only. Never persisted or shared.
        </p>
      </div>
    </div>
  );
}
