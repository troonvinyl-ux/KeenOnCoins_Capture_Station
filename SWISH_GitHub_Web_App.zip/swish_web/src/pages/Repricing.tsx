import { useTable, useUpdate } from '@/hooks/useSupabaseQuery';
import { formatCurrency, statusVariant, truncate } from '@/lib/utils';
import { RefreshCw, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { callEdgeFunction } from '@/lib/supabase';
import { toast } from 'sonner';
import { useState } from 'react';

export default function Repricing() {
  const qc = useQueryClient();
  const [repricing, setRepricing] = useState<string | null>(null);

  const { data, isLoading, error } = useTable('listings', {
    filter: { status: 'active' },
    order: { column: 'updated_at', ascending: true },
  });

  const update = useUpdate('listings');
  const items = (data || []) as Record<string, unknown>[];

  const handleReprice = async (listingId: string) => {
    setRepricing(listingId);
    const { data, error } = await callEdgeFunction('reprice', { listing_id: listingId });
    if (error) toast.error(error.message);
    else {
      toast.success('Repriced');
      qc.invalidateQueries({ queryKey: ['listings'] });
    }
    setRepricing(null);
  };

  const handleBulkReprice = async () => {
    const { error } = await callEdgeFunction('reprice-all', {});
    if (error) toast.error(error.message);
    else { toast.success('Bulk reprice triggered'); qc.invalidateQueries({ queryKey: ['listings'] }); }
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Repricing</h1>
          <p className="page-subtitle">{items.length} active listings</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => qc.invalidateQueries({ queryKey: ['listings'] })} className="btn-ghost"><RefreshCw className="w-3.5 h-3.5" /></button>
          <button onClick={handleBulkReprice} className="btn-primary"><RefreshCw className="w-3.5 h-3.5" />Reprice All</button>
        </div>
      </div>

      <div className="swish-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Loading listings…</div>
        ) : error ? (
          <div className="p-8 text-center text-destructive text-sm">{(error as Error).message}</div>
        ) : items.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground text-sm">No active listings for repricing</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr>
                <th>Listing</th><th>Platform</th><th className="text-right">Current Price</th>
                <th className="text-right">Suggested</th><th>Trend</th><th>Actions</th>
              </tr></thead>
              <tbody>
                {items.map(l => {
                  const current = l.price as number;
                  const suggested = (l.suggested_price || l.recommended_price) as number | undefined;
                  const diff = suggested && current ? suggested - current : null;
                  return (
                    <tr key={l.id as string}>
                      <td><span className="text-xs font-medium">{truncate((l.title || 'Listing') as string, 40)}</span></td>
                      <td className="text-xs capitalize">{(l.platform || '—') as string}</td>
                      <td className="text-right text-xs font-semibold swish-gold">{formatCurrency(current)}</td>
                      <td className="text-right text-xs">{suggested ? formatCurrency(suggested) : '—'}</td>
                      <td>
                        {diff !== null ? (
                          <span className={`flex items-center gap-1 text-xs ${diff > 0 ? 'text-success' : diff < 0 ? 'text-destructive' : 'text-muted-foreground'}`}>
                            {diff > 0 ? <TrendingUp className="w-3 h-3" /> : diff < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                            {diff !== 0 ? `${diff > 0 ? '+' : ''}${formatCurrency(diff)}` : 'No change'}
                          </span>
                        ) : '—'}
                      </td>
                      <td>
                        <button
                          onClick={() => handleReprice(l.id as string)}
                          disabled={repricing === l.id}
                          className="btn-ghost py-1 px-2 text-xs"
                        >
                          {repricing === l.id ? 'Repricing…' : 'Reprice'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
