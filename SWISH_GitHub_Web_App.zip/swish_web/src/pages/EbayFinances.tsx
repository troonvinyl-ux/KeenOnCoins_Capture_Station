import { useEffect, useState } from 'react';
import { callEdgeFunction } from '@/lib/supabase';
import { useTable } from '@/hooks/useSupabaseQuery';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Wallet, RefreshCw } from 'lucide-react';

export default function EbayFinances() {
  const [summary, setSummary] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(true);

  const { data: payouts } = useTable('ebay_payouts', { order: { column: 'created_at', ascending: false }, limit: 50 });
  const { data: transactions } = useTable('ebay_transactions', { order: { column: 'created_at', ascending: false }, limit: 50 });

  useEffect(() => {
    callEdgeFunction('ebay-finances', {}).then(({ data }) => {
      setSummary(data as Record<string, unknown>);
      setLoading(false);
    });
  }, []);

  const payoutItems = (payouts || []) as Record<string, unknown>[];
  const txItems = (transactions || []) as Record<string, unknown>[];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">eBay Finances</h1>
          <p className="page-subtitle">Payouts, transactions and financial data</p>
        </div>
        <button onClick={() => callEdgeFunction('ebay-finances', {}).then(({ data }) => setSummary(data as Record<string, unknown>))} className="btn-ghost">
          <RefreshCw className="w-3.5 h-3.5" />Refresh
        </button>
      </div>

      {loading ? (
        <div className="p-8 text-center text-muted-foreground text-sm">Loading financial data…</div>
      ) : summary ? (
        <div className="swish-card p-5">
          <h3 className="text-sm font-semibold mb-3">Financial Summary</h3>
          {typeof summary === 'object' && summary.available_balance !== undefined ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Available Balance', value: formatCurrency((summary.available_balance as Record<string, unknown>)?.value as number || summary.available_balance as number) },
                { label: 'Pending Payout', value: formatCurrency((summary.pending_payout as Record<string, unknown>)?.value as number || summary.pending_payout as number) },
                { label: 'Total Revenue', value: formatCurrency(summary.total_revenue as number) },
                { label: 'Total Fees', value: formatCurrency(summary.total_fees as number) },
              ].map(s => (
                <div key={s.label} className="stat-card">
                  <div className="stat-value swish-gold">{s.value}</div>
                  <div className="stat-label">{s.label}</div>
                </div>
              ))}
            </div>
          ) : (
            <pre className="text-xs text-muted-foreground bg-secondary/40 p-3 rounded overflow-auto max-h-48 scrollbar-thin">
              {JSON.stringify(summary, null, 2)}
            </pre>
          )}
        </div>
      ) : null}

      {/* Payouts */}
      {payoutItems.length > 0 && (
        <div className="swish-card p-4">
          <h3 className="text-sm font-semibold mb-3">Recent Payouts</h3>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr><th>Date</th><th>Status</th><th className="text-right">Amount</th><th>Method</th></tr></thead>
              <tbody>
                {payoutItems.slice(0, 20).map(p => (
                  <tr key={p.id as string}>
                    <td className="text-xs">{formatDate(p.created_at as string)}</td>
                    <td className="text-xs capitalize">{(p.status || '—') as string}</td>
                    <td className="text-right text-xs font-semibold swish-gold">{formatCurrency((p.amount || p.payout_amount) as number)}</td>
                    <td className="text-xs">{(p.method || p.payment_method || '—') as string}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Transactions */}
      {txItems.length > 0 && (
        <div className="swish-card p-4">
          <h3 className="text-sm font-semibold mb-3">Transactions</h3>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr><th>Date</th><th>Type</th><th>Description</th><th className="text-right">Amount</th></tr></thead>
              <tbody>
                {txItems.slice(0, 30).map(t => (
                  <tr key={t.id as string}>
                    <td className="text-xs">{formatDate(t.created_at as string)}</td>
                    <td className="text-xs capitalize">{(t.type || t.transaction_type || '—') as string}</td>
                    <td className="text-xs text-muted-foreground">{(t.description || '—') as string}</td>
                    <td className={`text-right text-xs font-semibold ${Number(t.amount) >= 0 ? 'swish-gold' : 'text-destructive'}`}>
                      {formatCurrency(t.amount as number)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
