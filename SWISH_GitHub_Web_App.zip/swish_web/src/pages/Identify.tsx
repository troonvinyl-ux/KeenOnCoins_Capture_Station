import { useState, useRef } from 'react';
import { callEdgeFunction } from '@/lib/supabase';
import { getSupabaseClient } from '@/lib/supabase';
import { Upload, Zap, X, CheckCircle, AlertCircle, Package } from 'lucide-react';
import { toast } from 'sonner';
import { formatCurrency } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

interface Candidate {
  title?: string;
  brand?: string;
  model?: string;
  category?: string;
  confidence?: number;
  estimated_value?: number;
  description?: string;
  [key: string]: unknown;
}

interface IdentifyResult {
  candidates?: Candidate[];
  item_id?: string;
  identification?: Candidate;
  [key: string]: unknown;
}

export default function Identify() {
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [images, setImages] = useState<string[]>([]);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<IdentifyResult | null>(null);
  const [selected, setSelected] = useState<number>(0);

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach(file => {
      const url = URL.createObjectURL(file);
      setImages(p => [...p, url]);
      setImageFiles(p => [...p, file]);
    });
  };

  const removeImage = (i: number) => {
    setImages(p => p.filter((_, idx) => idx !== i));
    setImageFiles(p => p.filter((_, idx) => idx !== i));
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  };

  const identify = async () => {
    if (imageFiles.length === 0) { toast.error('Add at least one image'); return; }
    setLoading(true);
    setResult(null);

    // Upload images to storage first
    const sb = getSupabaseClient();
    const uploadedUrls: string[] = [];

    if (sb) {
      for (const file of imageFiles) {
        const path = `identify/${Date.now()}_${file.name}`;
        const { data, error } = await sb.storage.from('images').upload(path, file, { upsert: true });
        if (!error && data) {
          const { data: urlData } = sb.storage.from('images').getPublicUrl(path);
          if (urlData?.publicUrl) uploadedUrls.push(urlData.publicUrl);
        }
      }
    }

    const { data, error } = await callEdgeFunction('identify', {
      images: uploadedUrls.length > 0 ? uploadedUrls : images,
      image_data: uploadedUrls.length === 0 ? 'local' : undefined,
    });

    if (error) { toast.error(error.message); }
    else {
      setResult(data as IdentifyResult);
      toast.success('Identification complete');
    }
    setLoading(false);
  };

  const saveItem = async (candidate: Candidate) => {
    if (!result?.item_id) {
      const sb = getSupabaseClient();
      if (!sb) return;
      const { data, error } = await sb.from('items').insert({
        canonical_title: candidate.title,
        attributes: { brand: candidate.brand, model: candidate.model, category: candidate.category, description: candidate.description, identification_data: candidate },
        valuation_mid: candidate.estimated_value,
        expected_selling_price: candidate.estimated_value,
        identification_confidence: candidate.confidence,
        status: 'active',
        media: uploadedUrls.length ? uploadedUrls : images,
      }).select().single();
      if (error) { toast.error(error.message); return; }
      toast.success('Item saved to inventory');
      navigate(`/inventory/${(data as Record<string, unknown>).id}`);
    } else {
      navigate(`/inventory/${result.item_id}`);
    }
  };

  const candidates = result?.candidates || (result?.identification ? [result.identification] : []);

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      <div className="page-header">
        <h1 className="page-title">Identify Item</h1>
        <p className="page-subtitle">Upload images to identify and value an item using AI</p>
      </div>

      {/* Upload zone */}
      <div
        className="swish-card p-6 border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer"
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
        onClick={() => fileRef.current?.click()}
      >
        <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={e => handleFiles(e.target.files)} />
        <div className="text-center">
          <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm font-medium">Drop images here or click to upload</p>
          <p className="text-xs text-muted-foreground mt-1">Multiple images supported for better identification accuracy</p>
        </div>
      </div>

      {/* Image preview */}
      {images.length > 0 && (
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
          {images.map((img, i) => (
            <div key={i} className="relative aspect-square">
              <img src={img} alt="" className="w-full h-full object-cover rounded-lg" />
              <button onClick={() => removeImage(i)} className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center hover:opacity-90">
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <button onClick={identify} disabled={loading || images.length === 0} className="btn-primary">
        <Zap className="w-4 h-4" />{loading ? 'Identifying…' : 'Identify Item'}
      </button>

      {/* Results */}
      {loading && (
        <div className="swish-card p-8 text-center">
          <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Analysing images…</p>
        </div>
      )}

      {candidates.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold">Identification Results</h3>
          {candidates.map((c, i) => (
            <div
              key={i}
              className={`swish-card p-4 cursor-pointer border-2 transition-colors ${selected === i ? 'border-primary' : 'border-transparent hover:border-primary/40'}`}
              onClick={() => setSelected(i)}
            >
              <div className="flex items-start gap-4">
                <div className="w-5 h-5 rounded-full border-2 shrink-0 mt-0.5 flex items-center justify-center transition-colors"
                  style={{ borderColor: selected === i ? 'hsl(var(--primary))' : 'hsl(var(--border))' }}>
                  {selected === i && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm">{c.title || `Candidate ${i + 1}`}</span>
                    {c.brand && <span className="text-xs text-muted-foreground">{c.brand}</span>}
                    {c.confidence && (
                      <span className={`text-xs font-medium ${c.confidence >= 0.8 ? 'text-success' : c.confidence >= 0.5 ? 'text-warning' : 'text-destructive'}`}>
                        {Math.round(c.confidence * 100)}% confident
                      </span>
                    )}
                  </div>
                  {c.category && <p className="text-xs text-muted-foreground mt-0.5">{c.category}{c.model ? ` · ${c.model}` : ''}</p>}
                  {c.description && <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{c.description}</p>}
                  {c.estimated_value && (
                    <p className="text-sm font-bold swish-gold mt-2">Est. {formatCurrency(c.estimated_value)}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
          <button onClick={() => saveItem(candidates[selected])} className="btn-primary">
            <Package className="w-3.5 h-3.5" />Save to Inventory
          </button>
        </div>
      )}

      {result && candidates.length === 0 && (
        <div className="swish-card p-6 text-center">
          <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">No identification results returned</p>
          <pre className="text-xs text-left bg-secondary/50 p-3 rounded mt-3 overflow-auto max-h-40 scrollbar-thin">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
