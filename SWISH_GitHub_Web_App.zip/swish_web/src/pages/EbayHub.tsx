import { useEffect, useState } from 'react';
import { callEdgeFunction } from '@/lib/supabase';
import { getSupabaseClient } from '@/lib/supabase';
import { useTable } from '@/hooks/useSupabaseQuery';
import { formatDate, formatDateTime } from '@/lib/utils';
import { RefreshCw, CheckCircle, AlertCircle, ExternalLink, Link2, Link2Off } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

export default function EbayHub() {
  const [account, setAccount] = useState<Record<string, unknown> | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const { data: accounts } = useTable('ebay_accounts', { limit: 1 });

  useEffect(() => {
    if (accounts && accounts.length > 0) setAccount(accounts[0] as Record<string, unknown>);
  }, [accounts]);

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const { data, error } = await callEdgeFunction('ebay-sync', {});
      if (error) throw error;
      toast.success('Existing eBay connection checked and synced');
      window.location.reload();
    } catch (e) { toast.error(e instanceof Error ? e.message : String(e)); }
    finally { setConnecting(false); }
  };

  const handleSync = async () => {
    setSyncing(true);
    const { error } = await callEdgeFunction('ebay-sync', {});
    if (error) toast.error(error.message);
    else toast.success('eBay sync triggered');
    setSyncing(false);
  };

  const isConnected = account && account.status === 'active';
  const tokenExpiry = account?.token_expires_at as string | undefined;
  const tokenExpired = tokenExpiry && new Date(tokenExpiry) < new Date();

  const QUICK_LINKS = [
    { to: '/ebay/listings', label: 'Listings' },
    { to: '/ebay/orders', label: 'Orders' },
    { to: '/ebay/messages', label: 'Messages' },
    { to: '/ebay/offers', label: 'Offers' },
    { to: '/ebay/returns', label: 'Returns' },
    { to: '/ebay/cases', label: 'Cases' },
    { to: '/ebay/finances', label: 'Finances' },
    { to: '/ebay/analytics', label: 'Analytics' },
    { to: '/ebay/import', label: 'Import' },
    { to: '/ebay/logs', label: 'Logs' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title flex items-center gap-2">
          <span className="text-base font-bold bg-primary text-primary-foreground px-2 py-0.5 rounded">eB</span>
          eBay Hub
        </h1>
        <p className="page-subtitle">Manage your eBay integration</p>
      </div>

      {/* Account status */}
      <div className="swish-card p-5">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isConnected ? 'bg-green-500/15' : 'bg-destructive/15'}`}>
              {isConnected ? <CheckCircle className="w-5 h-5 text-success" /> : <AlertCircle className="w-5 h-5 text-destructive" />}
            </div>
            <div>
              <div className="font-semibold text-sm">
                {account ? (account.username as string || 'eBay Account') : 'No eBay Account Connected'}
              </div>
              <div className="text-xs text-muted-foreground">
                {isConnected ? (
                  tokenExpired ? 'Token expired — reconnection needed' : `Token valid until ${formatDateTime(tokenExpiry)}`
                ) : 'Connect your eBay account to start selling'}
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            {isConnected && (
              <button onClick={handleSync} disabled={syncing} className="btn-secondary">
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
                {syncing ? 'Syncing…' : 'Sync Now'}
              </button>
            )}
            <button onClick={handleConnect} disabled={connecting} className="btn-primary">
              {isConnected ? <Link2 className="w-3.5 h-3.5" />}
              {connecting ? 'Checking…' : isConnected ? 'Check eBay connection' : 'Check eBay connection'}
            </button>
          </div>
        </div>
      </div>

      {/* Quick nav */}
      <div>
        <h3 className="text-sm font-semibold mb-3">eBay Sections</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {QUICK_LINKS.map(l => (
            <Link key={l.to} to={l.to} className="swish-card p-4 text-center hover:border-primary/40 transition-colors text-sm font-medium">
              {l.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Account details */}
      {account && (
        <div className="swish-card p-4">
          <h3 className="text-sm font-semibold mb-3">Account Details</h3>
          <pre className="text-xs text-muted-foreground bg-secondary/40 p-3 rounded overflow-auto max-h-48 scrollbar-thin">
            {JSON.stringify(account, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
