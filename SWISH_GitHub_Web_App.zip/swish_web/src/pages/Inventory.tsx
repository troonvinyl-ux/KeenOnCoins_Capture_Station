import { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useTable } from '@/hooks/useSupabaseQuery';
import { formatCurrency, formatDate, statusVariant, truncate } from '@/lib/utils';
import { Package, Search, Plus, Filter, RefreshCw } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';

export default function Inventory() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get('q') || '');
  const [status, setStatus] = useState('');
  const qc = useQueryClient();

  const { data, isLoading, error } = useTable('inventory', {
    order: { column: 'created_at', ascending: false },
    search: search ? { column: 'title', query: search } : undefined,
    filter: status ? { status } : undefined,
  });

  const items = (data || []) as Record<string, unknown>[];

  const handleSearch = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') setSearchParams(search ? { q: search } : {});
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="page-header flex items-center justify-between gap-4">
        <div>
          <h1 className="page-title">Inventory</h1>
          <p className="page-subtitle">{items.length} items loaded</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => qc.invalidateQueries({ queryKey: ['inventory'] })} className="btn-ghost">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <Link to="/inventory/new" className="btn-primary">
            <Plus className="w-3.5 h-3.5" />New Item
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48 max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={handleSearch}
            placeholder="Search inventory…"
            className="input-field pl-8"
          />
        </div>
        <select value={status} onChange={e => setStatus(e.target.value)} className="input-field w-auto min-w-32">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="listed">Listed</option>
          <option value="sold">Sold</option>
          <option value="draft">Draft</option>
          <option value="review">Review</option>
        </select>
      </div>

      {/* Table */}
      <div className="swish-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Loading inventory…</div>
        ) : error ? (
          <div className="p-8 text-center text-destructive text-sm">
            Error: {error instanceof Error ? error.message : 'Failed to load'}
          </div>
        ) : items.length === 0 ? (
          <div className="p-12 text-center">
            <Package className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">No inventory items found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>SKU</th>
                  <th>Condition</th>
                  <th>Status</th>
                  <th className="text-right">Cost</th>
                  <th className="text-right">Valuation</th>
                  <th>Added</th>
                </tr>
              </thead>
              <tbody>
                {items.map(item => (
                  <tr key={item.id as string} onClick={() => window.location.href = `/inventory/${item.id}`} className="cursor-pointer">
                    <td>
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded bg-secondary shrink-0 overflow-hidden">
                          {item.image_url ? (
                            <img src={item.image_url as string} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <Package className="w-4 h-4 text-muted-foreground m-2" />
                          )}
                        </div>
                        <div>
                          <div className="font-medium text-xs">{truncate((item.title || item.name || 'Untitled') as string, 40)}</div>
                          {item.brand && <div className="text-xs text-muted-foreground">{item.brand as string}</div>}
                        </div>
                      </div>
                    </td>
                    <td><span className="text-xs font-mono text-muted-foreground">{(item.sku || '—') as string}</span></td>
                    <td><span className="text-xs">{(item.condition || '—') as string}</span></td>
                    <td>
                      {item.status ? (
                        <span className={statusVariant(item.status as string)}>{item.status as string}</span>
                      ) : '—'}
                    </td>
                    <td className="text-right text-xs">{formatCurrency((item.cost_price || item.purchase_price) as number)}</td>
                    <td className="text-right text-xs font-medium swish-gold">{formatCurrency((item.valuation || item.sale_price) as number)}</td>
                    <td className="text-xs text-muted-foreground">{formatDate(item.created_at as string)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
