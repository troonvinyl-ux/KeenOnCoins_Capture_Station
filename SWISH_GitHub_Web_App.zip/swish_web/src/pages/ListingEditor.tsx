import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useTableRow, useUpsert } from '@/hooks/useSupabaseQuery';
import { callEdgeFunction, getTenantId } from '@/lib/supabase';
import { ArrowLeft, Save, Zap, Send, SquareX } from 'lucide-react';
import { toast } from 'sonner';

export default function ListingEditor() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const { data } = useTableRow('listings', isNew ? null : id);
  const upsert = useUpsert('listings');
  const [form, setForm] = useState<Record<string, unknown>>({ platform: 'ebay', status: 'draft', listing_type: 'FIXED_PRICE', quantity: 1, best_offer_enabled: false, delivery_method: 'Simple Delivery' });
  const [working, setWorking] = useState(false);

  useEffect(() => { if (data) setForm(data as Record<string, unknown>); }, [data]);
  const f=(key:string):string => String(form[key] ?? '');
  const setF=(key:string,val:unknown)=>setForm(p=>({...p,[key]:val}));

  const save=()=>upsert.mutate(form,{onSuccess:saved=>{toast.success('Listing saved');if(isNew)navigate(`/listings/${(saved as any).id}`)},onError:e=>toast.error(e.message)});

  const publish=async()=>{
    if(!form.id){toast.error('Save the listing first');return;}
    setWorking(true);
    try{
      const tenantId=await getTenantId();
      const media=Array.isArray(form.media_urls)?form.media_urls:[];
      const attrs=Array.isArray(form.item_specifics)?form.item_specifics:[];
      const {error}=await callEdgeFunction('publish-listing',{tenantId,listingId:form.id,listingType:form.listing_type||'FIXED_PRICE',categoryId:form.category_id||form.categoryId||null,deliveryMethod:'SIMPLE_DELIVERY',title:f('title').slice(0,80),description:f('description'),price:Number(form.price)||0,quantity:Number(form.quantity)||1,condition:f('condition'),conditionDescription:f('condition_description'),itemSpecifics:attrs,mediaUrls:media});
      if(error)throw error; toast.success('Published to eBay'); setF('status','active');
    }catch(e){toast.error(e instanceof Error?e.message:String(e))}finally{setWorking(false)}
  };
  const end=async()=>{if(!form.id)return;setWorking(true);try{const tenantId=await getTenantId();const {error}=await callEdgeFunction('end-listing',{tenantId,listingId:form.id,externalListingId:form.external_listing_id||form.external_id});if(error)throw error;toast.success('eBay listing ended');setF('status','ended')}catch(e){toast.error(e instanceof Error?e.message:String(e))}finally{setWorking(false)}};

  return <div className="max-w-3xl space-y-4 animate-fade-in">
    <div className="flex items-center gap-3"><Link to="/listings" className="btn-ghost py-1.5 px-2"><ArrowLeft className="w-4 h-4"/></Link><h1 className="page-title flex-1">{isNew?'New eBay Listing':'Edit eBay Listing'}</h1><div className="flex gap-2">{!isNew&&<><button onClick={publish} disabled={working} className="btn-primary"><Send className="w-3.5 h-3.5"/>{working?'Working…':'List / Revise on eBay'}</button><button onClick={end} disabled={working} className="btn-danger"><SquareX className="w-3.5 h-3.5"/>End</button></>}<button onClick={save} disabled={upsert.isPending} className="btn-secondary"><Save className="w-3.5 h-3.5"/>Save</button></div></div>
    <div className="swish-card p-5 space-y-4">
      <div><label className="text-xs text-muted-foreground">Title *</label><input value={f('title')} onChange={e=>setF('title',e.target.value)} className="input-field mt-0.5" maxLength={80}/></div>
      <div><label className="text-xs text-muted-foreground">Description</label><textarea value={f('description')} onChange={e=>setF('description',e.target.value)} rows={7} className="input-field mt-0.5"/></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="text-xs text-muted-foreground">Price (£)</label><input type="number" step="0.01" value={f('price')} onChange={e=>setF('price',Number(e.target.value))} className="input-field mt-0.5"/></div>
        <div><label className="text-xs text-muted-foreground">Quantity</label><input type="number" min="1" value={f('quantity')} onChange={e=>setF('quantity',Number(e.target.value))} className="input-field mt-0.5"/></div>
        <div><label className="text-xs text-muted-foreground">Condition</label><input value={f('condition')} onChange={e=>setF('condition',e.target.value)} className="input-field mt-0.5"/></div>
        <div><label className="text-xs text-muted-foreground">Category ID</label><input value={f('category_id')} onChange={e=>setF('category_id',e.target.value)} className="input-field mt-0.5" placeholder="eBay leaf category ID"/></div>
        <div><label className="text-xs text-muted-foreground">Listing Type</label><select value={f('listing_type')||'FIXED_PRICE'} onChange={e=>setF('listing_type',e.target.value)} className="input-field mt-0.5"><option value="FIXED_PRICE">Fixed price</option><option value="AUCTION">Auction</option></select></div>
        <div><label className="text-xs text-muted-foreground">Delivery</label><input value="Simple Delivery" readOnly className="input-field mt-0.5 opacity-70"/></div>
      </div>
      <div className="rounded-lg bg-secondary/40 p-3 text-xs text-muted-foreground"><Zap className="inline w-3 h-3 mr-1"/>The GitHub web app uses the existing SWISH eBay listing engine. eBay credentials remain server-side.</div>
    </div>
  </div>;
}
