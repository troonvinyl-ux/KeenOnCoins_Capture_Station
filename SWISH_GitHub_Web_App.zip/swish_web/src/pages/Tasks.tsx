import { useState } from 'react';
import { useTable, useInsert, useUpdate, useDelete } from '@/hooks/useSupabaseQuery';
import { formatDate, statusVariant } from '@/lib/utils';
import { CheckSquare, Plus, RefreshCw, X, Square } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export default function Tasks() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState('open');
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', due_date: '' });

  const { data, isLoading, error } = useTable('tasks', {
    filter: filter !== 'all' ? { status: filter } : undefined,
    order: { column: 'created_at', ascending: false },
  });

  const insert = useInsert('tasks');
  const update = useUpdate('tasks');
  const del = useDelete('tasks');

  const items = (data || []) as Record<string, unknown>[];

  const handleAdd = () => {
    if (!form.title.trim()) { toast.error('Title required'); return; }
    insert.mutate({ ...form, status: 'open' }, {
      onSuccess: () => { toast.success('Task created'); setShowForm(false); setForm({ title: '', description: '', priority: 'medium', due_date: '' }); },
      onError: e => toast.error(e.message),
    });
  };

  const toggleComplete = (id: string, current: string) => {
    update.mutate({ id, updates: { status: current === 'completed' ? 'open' : 'completed', completed_at: current !== 'completed' ? new Date().toISOString() : null } }, {
      onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
      onError: e => toast.error(e.message),
    });
  };

  const priorityColor = (p: string) => {
    if (p === 'high') return 'text-destructive';
    if (p === 'medium') return 'text-warning';
    return 'text-muted-foreground';
  };

  return (
    <div className="space-y-4 animate-fade-in max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Tasks</h1>
          <p className="page-subtitle">{items.length} tasks</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => qc.invalidateQueries({ queryKey: ['tasks'] })} className="btn-ghost"><RefreshCw className="w-3.5 h-3.5" /></button>
          <button onClick={() => setShowForm(true)} className="btn-primary"><Plus className="w-3.5 h-3.5" />New Task</button>
        </div>
      </div>

      <div className="flex gap-1">
        {['all', 'open', 'completed'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-colors ${filter === f ? 'bg-primary text-primary-foreground' : 'btn-ghost'}`}>
            {f}
          </button>
        ))}
      </div>

      {showForm && (
        <div className="swish-card p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold">New Task</h3>
            <button onClick={() => setShowForm(false)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
          </div>
          <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} className="input-field" placeholder="Task title *" />
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={2} className="input-field" placeholder="Description (optional)" />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground">Priority</label>
              <select value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))} className="input-field mt-0.5">
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Due Date</label>
              <input type="date" value={form.due_date} onChange={e => setForm(p => ({ ...p, due_date: e.target.value }))} className="input-field mt-0.5" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={handleAdd} disabled={insert.isPending} className="btn-primary">{insert.isPending ? 'Adding…' : 'Add Task'}</button>
            <button onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="p-8 text-center text-muted-foreground text-sm">Loading tasks…</div>
      ) : error ? (
        <div className="p-8 text-center text-destructive text-sm">{(error as Error).message}</div>
      ) : items.length === 0 ? (
        <div className="swish-card p-12 text-center">
          <CheckSquare className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No tasks found</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map(t => (
            <div key={t.id as string} className={`swish-card p-3 flex items-center gap-3 ${t.status === 'completed' ? 'opacity-60' : ''}`}>
              <button onClick={() => toggleComplete(t.id as string, t.status as string)} className="shrink-0 text-muted-foreground hover:text-primary transition-colors">
                {t.status === 'completed' ? <CheckSquare className="w-4 h-4 text-success" /> : <Square className="w-4 h-4" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className={`text-sm font-medium ${t.status === 'completed' ? 'line-through' : ''}`}>{(t.title || 'Untitled') as string}</div>
                {t.description && <div className="text-xs text-muted-foreground truncate">{t.description as string}</div>}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {t.priority && <span className={`text-xs font-medium capitalize ${priorityColor(t.priority as string)}`}>{t.priority as string}</span>}
                {t.due_date && <span className="text-xs text-muted-foreground">{formatDate(t.due_date as string)}</span>}
                <button onClick={() => del.mutate(t.id as string, { onSuccess: () => toast.success('Deleted') })} className="text-muted-foreground hover:text-destructive transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
