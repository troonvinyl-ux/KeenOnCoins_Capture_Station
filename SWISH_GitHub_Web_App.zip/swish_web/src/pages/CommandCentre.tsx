import { useEffect, useState } from 'react';
import { callEdgeFunction } from '@/lib/supabase';
import { useTable, useCount } from '@/hooks/useSupabaseQuery';
import { formatCurrency, formatRelative } from '@/lib/utils';
import { Terminal, RefreshCw, Zap, Package, Tag, ShoppingCart, Truck, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CommandCentre() {
  const [running, setRunning] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, unknown>>({});

  const { data: reviewItems } = useTable('inventory', { filter: { status: 'review' }, limit: 5 });
  const { data: recentActivity } = useTable('activity_log', { order: { column: 'created_at', ascending: false }, limit: 20 });
  const { data: invCount } = useCount('inventory');
  const { data: orderCount } = useCount('orders', { status: 'awaiting_dispatch' });

  const runFunction = async (fn: string, payload: Record<string, unknown> = {}) => {
    setRunning(fn);
    const { data, error } = await callEdgeFunction(fn, payload);
    setResults(p => ({ ...p, [fn]: error ? { error: error.message } : data }));
    setRunning(null);
  };

  const QUICK_ACTIONS = [
    { fn: 'sync-inventory', label: 'Sync Inventory', icon: Package, description: 'Sync all inventory from marketplaces' },
    { fn: 'sync-orders', label: 'Sync Orders', icon: ShoppingCart, description: 'Pull latest orders from all platforms' },
    { fn: 'sync-listings', label: 'Sync Listings', icon: Tag, description: 'Update listing statuses and data' },
    { fn: 'reprice-all', label: 'Reprice All', icon: RefreshCw, description: 'Run repricing across all active listings' },
    { fn: 'ebay-sync', label: 'eBay Sync', icon: () => <span className="text-xs font-bold">eB</span>, description: 'Full eBay account synchronisation' },
    { fn: 'batch-identify', label: 'Batch Identify', icon: Zap, description: 'Identify unidentified inventory items' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title flex items-center gap-2"><Terminal className="w-5 h-5 swish-gold" />Command Centre</h1>
        <p className="page-subtitle">Run backend operations and monitor system activity</p>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="stat-card">
          <div className="stat-value">{invCount ?? '—'}</div>
          <div className="stat-label">Total Inventory</div>
        </div>
        <div className="stat-card">
          <div className="stat-value text-warning">{orderCount ?? '—'}</div>
          <div className="stat-label">Awaiting Dispatch</div>
        </div>
        <Link to="/review-required" className="stat-card hover:border-primary/40 transition-colors">
          <div className="stat-value text-destructive">{(reviewItems?.length || 0)}</div>
          <div className="stat-label">Review Required</div>
        </Link>
        <div className="stat-card">
          <div className="text-xs text-success font-medium">● Connected</div>
          <div className="stat-label mt-1">Backend Status</div>
        </div>
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="text-sm font-semibold mb-3">Quick Actions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {QUICK_ACTIONS.map(a => (
            <button
              key={a.fn}
              onClick={() => runFunction(a.fn)}
              disabled={running === a.fn}
              className="swish-card p-4 text-left hover:border-primary/40 transition-colors disabled:opacity-60"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <a.icon className="w-4 h-4 swish-gold" />
                <span className="font-medium text-sm">{a.label}</span>
                {running === a.fn && <div className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin ml-auto" />}
              </div>
              <p className="text-xs text-muted-foreground">{a.description}</p>
              {results[a.fn] && (
                <div className="mt-2 text-xs bg-secondary/60 rounded p-2 font-mono text-left overflow-auto max-h-20 scrollbar-thin">
                  {JSON.stringify(results[a.fn], null, 2)}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Activity log */}
      <div className="swish-card p-4">
        <h3 className="text-sm font-semibold mb-3">Activity Log</h3>
        {(recentActivity || []).length > 0 ? (
          <div className="space-y-1.5">
            {(recentActivity as Record<string, unknown>[]).map(a => (
              <div key={a.id as string} className="flex items-center gap-3 py-1.5 border-b border-border/30 last:border-0">
                <div className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                <span className="flex-1 text-xs">{(a.description || a.action || JSON.stringify(a)) as string}</span>
                <span className="text-xs text-muted-foreground shrink-0">{formatRelative(a.created_at as string)}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-4">No activity log data (table may not exist)</p>
        )}
      </div>
    </div>
  );
}
