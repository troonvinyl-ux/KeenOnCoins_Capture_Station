import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getSupabaseClient } from '@/lib/supabase';

function tableName(table: string): string {
  if (table === 'inventory') return 'items';
  if (table === 'ebay_listings' || table === 'ebay_accounts') return table === 'ebay_listings' ? 'listings' : 'marketplace_connectors';
  return table;
}
function mapFilter(table: string, filter: Record<string, unknown> = {}) {
  const out = { ...filter };
  if (table === 'inventory') {
    if ('title' in out) { out.canonical_title = out.title; delete out.title; }
  }
  if (table === 'ebay_accounts') out.marketplace_id = 'ebay';
  if (table === 'ebay_listings') out.platform = 'ebay';
  return out;
}
function legacyItem(row: Record<string, any>) {
  const attrs = row.attributes && typeof row.attributes === 'object' ? row.attributes : {};
  const media = Array.isArray(row.media) ? row.media : [];
  return { ...row,
    title: row.title ?? row.canonical_title,
    name: row.name ?? row.canonical_title,
    image_url: row.image_url ?? media[0] ?? null,
    images: row.images ?? media,
    cost_price: row.cost_price ?? row.acquired_cost ?? 0,
    purchase_price: row.purchase_price ?? row.acquired_cost ?? 0,
    valuation: row.valuation ?? row.valuation_mid ?? row.expected_selling_price ?? 0,
    sale_price: row.sale_price ?? row.expected_selling_price ?? 0,
    brand: row.brand ?? attrs.brand,
    model: row.model ?? attrs.model,
    category: row.category ?? attrs.category,
    description: row.description ?? attrs.description,
    identification_data: row.identification_data ?? row.identification ?? attrs.identification,
    confidence: row.confidence ?? row.identification_confidence,
  };
}
function legacyListing(row: Record<string, any>) { return { ...row, external_id: row.external_id ?? row.external_listing_id, title: row.title ?? row.canonical_title, platform: row.platform ?? 'ebay' }; }
function normalizeRows(table: string, rows: any[]) { if (table === 'inventory') return rows.map(legacyItem); if (table === 'ebay_listings') return rows.map(legacyListing); if (table === 'ebay_accounts') return rows; return rows; }
function writeRow(table: string, row: Record<string, any>) {
  if (table !== 'inventory') return row;
  const out = { ...row };
  if ('title' in out && !('canonical_title' in out)) { out.canonical_title = out.title; delete out.title; }
  if ('cost_price' in out && !('acquired_cost' in out)) { out.acquired_cost = out.cost_price; delete out.cost_price; }
  if ('purchase_price' in out && !('acquired_cost' in out)) { out.acquired_cost = out.purchase_price; delete out.purchase_price; }
  if ('images' in out && !('media' in out)) { out.media = out.images; delete out.images; }
  if ('image_url' in out && !('media' in out) && out.image_url) { out.media = [out.image_url]; delete out.image_url; }
  if ('valuation' in out && !('valuation_mid' in out)) { out.valuation_mid = out.valuation; delete out.valuation; }
  return out;
}

export function useTable(table: string, options?: { select?: string; filter?: Record<string, unknown>; order?: { column: string; ascending?: boolean }; limit?: number; search?: { column: string; query: string }; enabled?: boolean; }) {
  const real = tableName(table);
  return useQuery({ queryKey: [table, options], enabled: options?.enabled !== false && !!getSupabaseClient(), queryFn: async () => {
    const sb = getSupabaseClient(); let q = sb.from(real).select(options?.select || '*');
    const filter = mapFilter(table, options?.filter || {});
    if (table === 'ebay_listings') filter.platform = 'ebay';
    Object.entries(filter).forEach(([k,v]) => { if (v != null) q = q.eq(k,v); });
    if (options?.search?.query) { const col = table === 'inventory' && options.search.column === 'title' ? 'canonical_title' : options.search.column; q = q.ilike(col, `%${options.search.query}%`); }
    if (options?.order) { const col = table === 'inventory' && options.order.column === 'created_at' ? 'created_at' : options.order.column; q = q.order(col, { ascending: options.order.ascending ?? false }); }
    if (table === 'ebay_accounts') q = q.eq('marketplace_id','ebay');
    if (options?.limit) q = q.limit(options.limit);
    const { data, error } = await q; if (error) throw error; return normalizeRows(table, data || []);
  }});
}
export function useTableRow(table: string, id: string | null | undefined, select = '*') { return useQuery({ queryKey:[table,id,select], enabled:!!id&&!!getSupabaseClient(), queryFn:async()=>{const {data,error}=await getSupabaseClient().from(tableName(table)).select(select).eq('id',id!).single();if(error)throw error;return table==='inventory'?legacyItem(data):data;} }); }
export function useUpsert(table: string) { const qc=useQueryClient(); return useMutation({mutationFn:async(row)=>{const {data,error}=await getSupabaseClient().from(tableName(table)).upsert(writeRow(table,row)).select().single();if(error)throw error;return table==='inventory'?legacyItem(data):data;},onSuccess:()=>qc.invalidateQueries({queryKey:[table]})}); }
export function useDelete(table: string) { const qc=useQueryClient(); return useMutation({mutationFn:async(id:string)=>{const {error}=await getSupabaseClient().from(tableName(table)).delete().eq('id',id);if(error)throw error;},onSuccess:()=>qc.invalidateQueries({queryKey:[table]})}); }
export function useInsert(table: string) { const qc=useQueryClient(); return useMutation({mutationFn:async(row)=>{const {data,error}=await getSupabaseClient().from(tableName(table)).insert(writeRow(table,row)).select().single();if(error)throw error;return table==='inventory'?legacyItem(data):data;},onSuccess:()=>qc.invalidateQueries({queryKey:[table]})}); }
export function useUpdate(table: string) { const qc=useQueryClient(); return useMutation({mutationFn:async({id,updates}:{id:string;updates:Record<string,unknown>})=>{const {data,error}=await getSupabaseClient().from(tableName(table)).update(writeRow(table,updates)).eq('id',id).select().single();if(error)throw error;return table==='inventory'?legacyItem(data):data;},onSuccess:()=>qc.invalidateQueries({queryKey:[table]})}); }
export function useCount(table:string,filter?:Record<string,unknown>){return useQuery({queryKey:[table,'count',filter],enabled:!!getSupabaseClient(),queryFn:async()=>{let q=getSupabaseClient().from(tableName(table)).select('*',{count:'exact',head:true});const f=mapFilter(table,filter||{});if(table==='ebay_accounts')f.marketplace_id='ebay';if(table==='ebay_listings')f.platform='ebay';Object.entries(f).forEach(([k,v])=>{if(v!=null)q=q.eq(k,v)});const {count,error}=await q;if(error)throw error;return count||0;}})}
