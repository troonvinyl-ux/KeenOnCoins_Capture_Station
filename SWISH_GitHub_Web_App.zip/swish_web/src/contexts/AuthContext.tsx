import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { getSupabaseClient, initSupabase, resetClient, getStoredAnonKey } from '@/lib/supabase';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  anonKeySet: boolean;
  setAnonKey: (key: string) => void;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [anonKeySet, setAnonKeySet] = useState(true);

  const setupAuth = useCallback(() => {
    const sb = getSupabaseClient();
    if (!sb) { setLoading(false); return; }
    sb.auth.getSession().then(({ data: { session } }) => {
      setSession(session); setUser(session?.user ?? null); setLoading(false);
    });
    const { data: { subscription } } = sb.auth.onAuthStateChange((_e, session) => {
      setSession(session); setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => { return setupAuth(); }, [setupAuth]);

  const setAnonKey = (key: string) => {
    initSupabase(key);
    setAnonKeySet(true);
    setLoading(true);
    setTimeout(() => setupAuth(), 100);
  };

  const signIn = async (email: string, password: string) => {
    const sb = getSupabaseClient();
    if (!sb) return { error: new Error('Not configured') };
    const { error } = await sb.auth.signInWithPassword({ email, password });
    return { error: error ? new Error(error.message) : null };
  };

  const signOut = async () => {
    const sb = getSupabaseClient();
    if (sb) await sb.auth.signOut();
    setUser(null); setSession(null); resetClient(); setAnonKeySet(true);
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, anonKeySet, setAnonKey, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
