# SWISH GitHub Pages web app

This is the free GitHub-hosted SWISH frontend. It connects to the existing OnSpace SWISH backend.

## Architecture
- GitHub Pages = frontend only
- Existing OnSpace backend = canonical database + existing Edge Functions
- Existing server-side eBay connector/credentials are reused
- No new database, auth system, or eBay credential store is created
- eBay listing submissions default to Simple Delivery

## Deploy
1. Create/use a GitHub repository.
2. Upload the contents of this project (not the outer ZIP folder).
3. Commit to the `main` branch.
4. Open GitHub **Settings → Pages** and set the source to **GitHub Actions**.
5. The included workflow builds and deploys the site automatically.

The app uses HashRouter so direct links work on GitHub Pages without server-side routing.

## Backend
The frontend is intentionally hard-wired to the existing SWISH OnSpace backend URL and public anon client key. eBay client secrets, access tokens and refresh tokens are never placed in this frontend.
